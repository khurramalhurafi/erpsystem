from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from app.db.database import get_db
from app.models.user import Customer
from app.core.security import get_current_user

router = APIRouter()

class CustomerIn(BaseModel):
    name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    country: Optional[str] = None
    company: Optional[str] = None

class CustomerOut(CustomerIn):
    id: int
    odoo_id: Optional[int] = None
    class Config:
        from_attributes = True

@router.get("/", response_model=List[CustomerOut])
def list_customers(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(Customer).offset(skip).limit(limit).all()

@router.post("/", response_model=CustomerOut)
def create_customer(data: CustomerIn, db: Session = Depends(get_db), _=Depends(get_current_user)):
    c = Customer(**data.dict())
    db.add(c); db.commit(); db.refresh(c)
    return c

@router.get("/{id}", response_model=CustomerOut)
def get_customer(id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    c = db.query(Customer).filter(Customer.id == id).first()
    if not c: raise HTTPException(404, "Customer not found")
    return c

@router.put("/{id}", response_model=CustomerOut)
def update_customer(id: int, data: CustomerIn, db: Session = Depends(get_db), _=Depends(get_current_user)):
    c = db.query(Customer).filter(Customer.id == id).first()
    if not c: raise HTTPException(404, "Customer not found")
    for k, v in data.dict().items():
        setattr(c, k, v)
    db.commit(); db.refresh(c)
    return c

@router.delete("/{id}")
def delete_customer(id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    c = db.query(Customer).filter(Customer.id == id).first()
    if not c: raise HTTPException(404, "Customer not found")
    db.delete(c); db.commit()
    return {"ok": True}
