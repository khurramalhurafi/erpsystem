from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from app.db.database import get_db
from app.models.user import Invoice, InvoiceLine, InvoiceStatus
from app.core.security import get_current_user

router = APIRouter()

class LineIn(BaseModel):
    description: str
    quantity: float = 1
    unit_price: float = 0
    product_id: Optional[int] = None

class InvoiceIn(BaseModel):
    number: Optional[str] = None
    customer_id: int
    due_date: Optional[datetime] = None
    notes: Optional[str] = None
    tax: float = 0
    lines: List[LineIn] = []

class InvoiceOut(BaseModel):
    id: int
    number: str
    customer_id: int
    status: str
    subtotal: float
    tax: float
    total: float
    issue_date: datetime
    due_date: Optional[datetime]
    notes: Optional[str]
    class Config:
        from_attributes = True

@router.get("/", response_model=List[InvoiceOut])
def list_invoices(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(Invoice).order_by(Invoice.created_at.desc()).offset(skip).limit(limit).all()

@router.post("/", response_model=InvoiceOut)
def create_invoice(data: InvoiceIn, db: Session = Depends(get_db), _=Depends(get_current_user)):
    count = db.query(Invoice).count()
    number = data.number or f"INV-{str(count + 1).zfill(5)}"
    subtotal = sum(l.quantity * l.unit_price for l in data.lines)
    total = subtotal + data.tax
    inv = Invoice(
        number=number, customer_id=data.customer_id,
        due_date=data.due_date, notes=data.notes,
        subtotal=subtotal, tax=data.tax, total=total
    )
    db.add(inv); db.flush()
    for l in data.lines:
        db.add(InvoiceLine(
            invoice_id=inv.id, description=l.description,
            quantity=l.quantity, unit_price=l.unit_price,
            total=l.quantity * l.unit_price, product_id=l.product_id
        ))
    db.commit(); db.refresh(inv)
    return inv

@router.get("/{id}", response_model=InvoiceOut)
def get_invoice(id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    inv = db.query(Invoice).filter(Invoice.id == id).first()
    if not inv: raise HTTPException(404, "Invoice not found")
    return inv

@router.put("/{id}/status")
def update_status(id: int, status: InvoiceStatus, db: Session = Depends(get_db), _=Depends(get_current_user)):
    inv = db.query(Invoice).filter(Invoice.id == id).first()
    if not inv: raise HTTPException(404, "Invoice not found")
    inv.status = status
    db.commit()
    return {"ok": True}
