from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.db.database import get_db
from app.models.user import Customer, Product, Invoice, Employee, InvoiceStatus
from app.core.security import get_current_user

router = APIRouter()

@router.get("/stats")
def get_stats(db: Session = Depends(get_db), _=Depends(get_current_user)):
    total_customers  = db.query(func.count(Customer.id)).scalar()
    total_products   = db.query(func.count(Product.id)).scalar()
    total_employees  = db.query(func.count(Employee.id)).filter(Employee.is_active == True).scalar()
    total_invoices   = db.query(func.count(Invoice.id)).scalar()
    paid_revenue     = db.query(func.sum(Invoice.total)).filter(Invoice.status == InvoiceStatus.paid).scalar() or 0
    pending_revenue  = db.query(func.sum(Invoice.total)).filter(Invoice.status == InvoiceStatus.sent).scalar() or 0
    overdue_count    = db.query(func.count(Invoice.id)).filter(Invoice.status == InvoiceStatus.overdue).scalar()

    recent_invoices = (
        db.query(Invoice)
        .order_by(Invoice.created_at.desc())
        .limit(5)
        .all()
    )

    return {
        "customers":       total_customers,
        "products":        total_products,
        "employees":       total_employees,
        "invoices":        total_invoices,
        "paid_revenue":    round(paid_revenue, 2),
        "pending_revenue": round(pending_revenue, 2),
        "overdue_count":   overdue_count,
        "recent_invoices": [
            {"id": i.id, "number": i.number, "total": i.total, "status": i.status, "date": str(i.issue_date)}
            for i in recent_invoices
        ]
    }
