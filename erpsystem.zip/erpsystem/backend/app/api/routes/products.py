from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from app.db.database import get_db
from app.models.user import Product
from app.core.security import get_current_user

router = APIRouter()

class ProductIn(BaseModel):
    name: str
    code: Optional[str] = None
    description: Optional[str] = None
    price: float = 0
    cost: float = 0
    stock: float = 0
    unit: str = "unit"
    category: Optional[str] = None

class ProductOut(ProductIn):
    id: int
    is_active: bool
    odoo_id: Optional[int] = None
    class Config:
        from_attributes = True

@router.get("/", response_model=List[ProductOut])
def list_products(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(Product).filter(Product.is_active == True).offset(skip).limit(limit).all()

@router.post("/", response_model=ProductOut)
def create_product(data: ProductIn, db: Session = Depends(get_db), _=Depends(get_current_user)):
    p = Product(**data.dict())
    db.add(p); db.commit(); db.refresh(p)
    return p

@router.get("/{id}", response_model=ProductOut)
def get_product(id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    p = db.query(Product).filter(Product.id == id).first()
    if not p: raise HTTPException(404, "Product not found")
    return p

@router.put("/{id}", response_model=ProductOut)
def update_product(id: int, data: ProductIn, db: Session = Depends(get_db), _=Depends(get_current_user)):
    p = db.query(Product).filter(Product.id == id).first()
    if not p: raise HTTPException(404, "Product not found")
    for k, v in data.dict().items():
        setattr(p, k, v)
    db.commit(); db.refresh(p)
    return p

@router.delete("/{id}")
def delete_product(id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    p = db.query(Product).filter(Product.id == id).first()
    if not p: raise HTTPException(404, "Product not found")
    p.is_active = False
    db.commit()
    return {"ok": True}
