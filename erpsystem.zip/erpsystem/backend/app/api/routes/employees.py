from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from app.db.database import get_db
from app.models.user import Employee
from app.core.security import get_current_user

router = APIRouter()

class EmployeeIn(BaseModel):
    name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    department: Optional[str] = None
    job_title: Optional[str] = None
    salary: float = 0
    hire_date: Optional[datetime] = None

class EmployeeOut(EmployeeIn):
    id: int
    is_active: bool
    odoo_id: Optional[int] = None
    class Config:
        from_attributes = True

@router.get("/", response_model=List[EmployeeOut])
def list_employees(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(Employee).filter(Employee.is_active == True).all()

@router.post("/", response_model=EmployeeOut)
def create_employee(data: EmployeeIn, db: Session = Depends(get_db), _=Depends(get_current_user)):
    e = Employee(**data.dict())
    db.add(e); db.commit(); db.refresh(e)
    return e

@router.get("/{id}", response_model=EmployeeOut)
def get_employee(id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    e = db.query(Employee).filter(Employee.id == id).first()
    if not e: raise HTTPException(404, "Employee not found")
    return e

@router.put("/{id}", response_model=EmployeeOut)
def update_employee(id: int, data: EmployeeIn, db: Session = Depends(get_db), _=Depends(get_current_user)):
    e = db.query(Employee).filter(Employee.id == id).first()
    if not e: raise HTTPException(404, "Employee not found")
    for k, v in data.dict().items():
        setattr(e, k, v)
    db.commit(); db.refresh(e)
    return e

@router.delete("/{id}")
def delete_employee(id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    e = db.query(Employee).filter(Employee.id == id).first()
    if not e: raise HTTPException(404, "Employee not found")
    e.is_active = False
    db.commit()
    return {"ok": True}
