from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from app.db.database import get_db
from app.models.user import Customer, Product, Employee, Invoice, InvoiceLine, InvoiceStatus
from app.core.security import get_current_user

router = APIRouter()

# ── Odoo 8 data shapes (paste your exported CSV/JSON data here) ──

class OdooCustomer(BaseModel):
    id: int
    name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    street: Optional[str] = None
    city: Optional[str] = None
    country: Optional[str] = None
    company_name: Optional[str] = None

class OdooProduct(BaseModel):
    id: int
    name: str
    default_code: Optional[str] = None
    description: Optional[str] = None
    list_price: float = 0
    standard_price: float = 0
    qty_available: float = 0
    uom_name: Optional[str] = None
    categ_name: Optional[str] = None

class OdooEmployee(BaseModel):
    id: int
    name: str
    work_email: Optional[str] = None
    mobile_phone: Optional[str] = None
    department_name: Optional[str] = None
    job_title: Optional[str] = None
    wage: float = 0

class ImportPayload(BaseModel):
    customers: List[OdooCustomer] = []
    products:  List[OdooProduct]  = []
    employees: List[OdooEmployee] = []

@router.post("/import")
def import_from_odoo(payload: ImportPayload, db: Session = Depends(get_db), _=Depends(get_current_user)):
    results = {"customers": 0, "products": 0, "employees": 0, "skipped": 0}

    for c in payload.customers:
        existing = db.query(Customer).filter(Customer.odoo_id == c.id).first()
        if existing:
            results["skipped"] += 1
            continue
        db.add(Customer(
            name=c.name, email=c.email, phone=c.phone,
            address=c.street, city=c.city, country=c.country,
            company=c.company_name, odoo_id=c.id
        ))
        results["customers"] += 1

    for p in payload.products:
        existing = db.query(Product).filter(Product.odoo_id == p.id).first()
        if existing:
            results["skipped"] += 1
            continue
        db.add(Product(
            name=p.name, code=p.default_code, description=p.description,
            price=p.list_price, cost=p.standard_price, stock=p.qty_available,
            unit=p.uom_name or "unit", category=p.categ_name, odoo_id=p.id
        ))
        results["products"] += 1

    for e in payload.employees:
        existing = db.query(Employee).filter(Employee.odoo_id == e.id).first()
        if existing:
            results["skipped"] += 1
            continue
        db.add(Employee(
            name=e.name, email=e.work_email, phone=e.mobile_phone,
            department=e.department_name, job_title=e.job_title,
            salary=e.wage, odoo_id=e.id
        ))
        results["employees"] += 1

    db.commit()
    return {"success": True, "imported": results}

@router.get("/status")
def import_status(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return {
        "customers_with_odoo_id": db.query(Customer).filter(Customer.odoo_id != None).count(),
        "products_with_odoo_id":  db.query(Product).filter(Product.odoo_id != None).count(),
        "employees_with_odoo_id": db.query(Employee).filter(Employee.odoo_id != None).count(),
    }
