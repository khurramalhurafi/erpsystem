from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.database import Base
import enum

class User(Base):
    __tablename__ = "users"
    id           = Column(Integer, primary_key=True, index=True)
    name         = Column(String(100))
    email        = Column(String(100), unique=True, index=True)
    password     = Column(String(200))
    role         = Column(String(50), default="staff")  # admin, manager, staff
    is_active    = Column(Boolean, default=True)
    created_at   = Column(DateTime(timezone=True), server_default=func.now())

class Customer(Base):
    __tablename__ = "customers"
    id           = Column(Integer, primary_key=True, index=True)
    name         = Column(String(200))
    email        = Column(String(100))
    phone        = Column(String(50))
    address      = Column(Text)
    city         = Column(String(100))
    country      = Column(String(100))
    company      = Column(String(200))
    odoo_id      = Column(Integer, nullable=True)  # original Odoo ID for migration tracking
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
    invoices     = relationship("Invoice", back_populates="customer")

class Product(Base):
    __tablename__ = "products"
    id           = Column(Integer, primary_key=True, index=True)
    name         = Column(String(200))
    code         = Column(String(100))
    description  = Column(Text)
    price        = Column(Float, default=0)
    cost         = Column(Float, default=0)
    stock        = Column(Float, default=0)
    unit         = Column(String(50), default="unit")
    category     = Column(String(100))
    odoo_id      = Column(Integer, nullable=True)
    is_active    = Column(Boolean, default=True)
    created_at   = Column(DateTime(timezone=True), server_default=func.now())

class InvoiceStatus(str, enum.Enum):
    draft    = "draft"
    sent     = "sent"
    paid     = "paid"
    overdue  = "overdue"
    cancelled = "cancelled"

class Invoice(Base):
    __tablename__ = "invoices"
    id           = Column(Integer, primary_key=True, index=True)
    number       = Column(String(100), unique=True)
    customer_id  = Column(Integer, ForeignKey("customers.id"))
    status       = Column(Enum(InvoiceStatus), default=InvoiceStatus.draft)
    issue_date   = Column(DateTime(timezone=True), server_default=func.now())
    due_date     = Column(DateTime(timezone=True))
    subtotal     = Column(Float, default=0)
    tax          = Column(Float, default=0)
    total        = Column(Float, default=0)
    notes        = Column(Text)
    odoo_id      = Column(Integer, nullable=True)
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
    customer     = relationship("Customer", back_populates="invoices")
    lines        = relationship("InvoiceLine", back_populates="invoice", cascade="all, delete-orphan")

class InvoiceLine(Base):
    __tablename__ = "invoice_lines"
    id           = Column(Integer, primary_key=True, index=True)
    invoice_id   = Column(Integer, ForeignKey("invoices.id"))
    product_id   = Column(Integer, ForeignKey("products.id"), nullable=True)
    description  = Column(String(500))
    quantity     = Column(Float, default=1)
    unit_price   = Column(Float, default=0)
    total        = Column(Float, default=0)
    invoice      = relationship("Invoice", back_populates="lines")

class Employee(Base):
    __tablename__ = "employees"
    id           = Column(Integer, primary_key=True, index=True)
    name         = Column(String(200))
    email        = Column(String(100))
    phone        = Column(String(50))
    department   = Column(String(100))
    job_title    = Column(String(100))
    salary       = Column(Float, default=0)
    hire_date    = Column(DateTime(timezone=True))
    is_active    = Column(Boolean, default=True)
    odoo_id      = Column(Integer, nullable=True)
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
