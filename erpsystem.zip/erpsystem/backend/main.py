from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import auth, dashboard, customers, products, invoices, employees, odoo_import
from app.db.database import engine, Base

Base.metadata.create_all(bind=engine)

app = FastAPI(title="ERP System API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router,         prefix="/api/auth",       tags=["auth"])
app.include_router(dashboard.router,    prefix="/api/dashboard",  tags=["dashboard"])
app.include_router(customers.router,    prefix="/api/customers",  tags=["customers"])
app.include_router(products.router,     prefix="/api/products",   tags=["products"])
app.include_router(invoices.router,     prefix="/api/invoices",   tags=["invoices"])
app.include_router(employees.router,    prefix="/api/employees",  tags=["employees"])
app.include_router(odoo_import.router,  prefix="/api/odoo",       tags=["odoo-import"])

@app.get("/api/health")
def health():
    return {"status": "ok"}
