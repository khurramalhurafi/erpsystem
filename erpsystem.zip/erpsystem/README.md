# ERP System

Modern ERP built with FastAPI + React + PostgreSQL.
Migrates data from Odoo 8.

## Stack
- **Backend**: Python 3.11 / FastAPI
- **Frontend**: React 18
- **Database**: PostgreSQL
- **Server**: Nginx + systemd

## Modules
- Dashboard (stats, revenue chart)
- Customers
- Products (with stock)
- Invoices (with line items)
- Employees
- Odoo 8 Data Import

## Local Development

### Backend
```bash
cd backend
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # edit with your DB credentials
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm start
```

## Deploy
Run `setup.sh` on a fresh Ubuntu 22.04 DigitalOcean droplet.
Push to GitHub → auto-deploys via webhook.

## First User
After deploy, register via:
```bash
curl -X POST http://YOUR_IP/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Admin","email":"admin@company.com","password":"yourpassword","role":"admin"}'
```
