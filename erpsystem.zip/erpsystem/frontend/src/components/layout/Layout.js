import React from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Users, Package, FileText, UserCog, Download, LogOut } from 'lucide-react';

const nav = [
  { to: '/dashboard',   icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/customers',   icon: Users,           label: 'Customers' },
  { to: '/products',    icon: Package,         label: 'Products' },
  { to: '/invoices',    icon: FileText,        label: 'Invoices' },
  { to: '/employees',   icon: UserCog,         label: 'Employees' },
  { to: '/odoo-import', icon: Download,        label: 'Odoo Import' },
];

export default function Layout() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  }

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-logo">
          <span>◈</span> ERP System
        </div>
        <nav className="sidebar-nav">
          {nav.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to} to={to}
              className={({ isActive }) => 'nav-item' + (isActive ? ' active' : '')}
            >
              <Icon /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="user-pill">
            <div className="user-avatar">{(user.name || 'U')[0].toUpperCase()}</div>
            <div className="user-info">
              <div className="user-name">{user.name || 'User'}</div>
              <div className="user-role">{user.role || 'staff'}</div>
            </div>
          </div>
          <button className="nav-item" onClick={logout} style={{ marginTop: 4 }}>
            <LogOut /> Logout
          </button>
        </div>
      </aside>
      <main className="main-content">
        <Outlet />
      </main>
    </div>
  );
}
