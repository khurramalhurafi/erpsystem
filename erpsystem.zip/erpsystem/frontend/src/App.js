import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import Products from './pages/Products';
import Invoices from './pages/Invoices';
import Employees from './pages/Employees';
import OdooImport from './pages/OdooImport';

function PrivateRoute({ children }) {
  return localStorage.getItem('token') ? children : <Navigate to="/login" />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
          <Route index element={<Navigate to="/dashboard" />} />
          <Route path="dashboard"  element={<Dashboard />} />
          <Route path="customers"  element={<Customers />} />
          <Route path="products"   element={<Products />} />
          <Route path="invoices"   element={<Invoices />} />
          <Route path="employees"  element={<Employees />} />
          <Route path="odoo-import" element={<OdooImport />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
