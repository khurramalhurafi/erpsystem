import React, { useEffect, useState } from 'react';
import { Plus, Search, Pencil, Trash2, X } from 'lucide-react';
import api from '../services/api';

const empty = { name: '', email: '', phone: '', address: '', city: '', country: '', company: '' };

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [search, setSearch]       = useState('');
  const [modal, setModal]         = useState(false);
  const [form, setForm]           = useState(empty);
  const [editId, setEditId]       = useState(null);
  const [loading, setLoading]     = useState(true);

  const load = () => api.get('/customers/').then(r => { setCustomers(r.data); setLoading(false); });
  useEffect(() => { load(); }, []);

  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.email || '').toLowerCase().includes(search.toLowerCase())
  );

  function openAdd() { setForm(empty); setEditId(null); setModal(true); }
  function openEdit(c) { setForm({ name: c.name, email: c.email||'', phone: c.phone||'', address: c.address||'', city: c.city||'', country: c.country||'', company: c.company||'' }); setEditId(c.id); setModal(true); }

  async function save() {
    if (editId) await api.put(`/customers/${editId}`, form);
    else await api.post('/customers/', form);
    setModal(false); load();
  }

  async function remove(id) {
    if (!window.confirm('Delete this customer?')) return;
    await api.delete(`/customers/${id}`); load();
  }

  return (
    <div>
      <div className="page-header page-header-row">
        <div>
          <h1>Customers</h1>
          <p>Manage your customer database</p>
        </div>
        <button className="btn btn-primary" onClick={openAdd}><Plus /> Add Customer</button>
      </div>

      <div className="card">
        <div className="search-bar" style={{ marginBottom: 18 }}>
          <Search /><input placeholder="Search by name or email..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {loading ? <div className="loading">Loading...</div> : filtered.length === 0 ? (
          <div className="empty-state"><p>No customers found</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Company</th><th>Email</th><th>Phone</th><th>City</th><th></th></tr></thead>
              <tbody>
                {filtered.map(c => (
                  <tr key={c.id}>
                    <td style={{ fontWeight: 500 }}>{c.name}</td>
                    <td style={{ color: 'var(--muted)' }}>{c.company || '—'}</td>
                    <td>{c.email || '—'}</td>
                    <td>{c.phone || '—'}</td>
                    <td>{c.city || '—'}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-ghost" style={{ padding: '5px 9px' }} onClick={() => openEdit(c)}><Pencil style={{ width: 13, height: 13 }} /></button>
                        <button className="btn btn-danger" style={{ padding: '5px 9px' }} onClick={() => remove(c.id)}><Trash2 style={{ width: 13, height: 13 }} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">{editId ? 'Edit Customer' : 'Add Customer'}</div>
              <button className="modal-close" onClick={() => setModal(false)}><X /></button>
            </div>
            <div className="form-grid">
              {[['name','Full Name','text',true],['company','Company','text',false],['email','Email','email',false],['phone','Phone','text',false],['city','City','text',false],['country','Country','text',false]].map(([key, label, type, req]) => (
                <div className="form-group" key={key}>
                  <label>{label}{req && ' *'}</label>
                  <input type={type} value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} required={req} />
                </div>
              ))}
            </div>
            <div className="form-group">
              <label>Address</label>
              <textarea value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} />
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
