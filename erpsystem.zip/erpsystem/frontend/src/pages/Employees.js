import React, { useEffect, useState } from 'react';
import { Plus, Search, Pencil, Trash2, X } from 'lucide-react';
import api from '../services/api';

const empty = { name: '', email: '', phone: '', department: '', job_title: '', salary: 0, hire_date: '' };

export default function Employees() {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch]       = useState('');
  const [modal, setModal]         = useState(false);
  const [form, setForm]           = useState(empty);
  const [editId, setEditId]       = useState(null);
  const [loading, setLoading]     = useState(true);

  const load = () => api.get('/employees/').then(r => { setEmployees(r.data); setLoading(false); });
  useEffect(() => { load(); }, []);

  const filtered = employees.filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    (e.department || '').toLowerCase().includes(search.toLowerCase())
  );

  function openAdd() { setForm(empty); setEditId(null); setModal(true); }
  function openEdit(e) {
    setForm({ name: e.name, email: e.email||'', phone: e.phone||'', department: e.department||'', job_title: e.job_title||'', salary: e.salary, hire_date: e.hire_date ? e.hire_date.split('T')[0] : '' });
    setEditId(e.id); setModal(true);
  }

  async function save() {
    const payload = { ...form, salary: +form.salary, hire_date: form.hire_date ? form.hire_date + 'T00:00:00' : null };
    if (editId) await api.put(`/employees/${editId}`, payload);
    else await api.post('/employees/', payload);
    setModal(false); load();
  }

  async function remove(id) {
    if (!window.confirm('Remove this employee?')) return;
    await api.delete(`/employees/${id}`); load();
  }

  return (
    <div>
      <div className="page-header page-header-row">
        <div><h1>Employees</h1><p>Manage your team</p></div>
        <button className="btn btn-primary" onClick={openAdd}><Plus /> Add Employee</button>
      </div>

      <div className="card">
        <div className="search-bar" style={{ marginBottom: 18 }}>
          <Search /><input placeholder="Search by name or department..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {loading ? <div className="loading">Loading...</div> : filtered.length === 0 ? (
          <div className="empty-state"><p>No employees found</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Department</th><th>Job Title</th><th>Salary</th><th>Hire Date</th><th></th></tr></thead>
              <tbody>
                {filtered.map(e => (
                  <tr key={e.id}>
                    <td style={{ fontWeight: 500 }}>{e.name}</td>
                    <td>{e.department || '—'}</td>
                    <td style={{ color: 'var(--muted)' }}>{e.job_title || '—'}</td>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 13 }}>${e.salary?.toLocaleString()}</td>
                    <td style={{ color: 'var(--muted)' }}>{e.hire_date ? new Date(e.hire_date).toLocaleDateString() : '—'}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-ghost" style={{ padding: '5px 9px' }} onClick={() => openEdit(e)}><Pencil style={{ width: 13 }} /></button>
                        <button className="btn btn-danger" style={{ padding: '5px 9px' }} onClick={() => remove(e.id)}><Trash2 style={{ width: 13 }} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">{editId ? 'Edit Employee' : 'Add Employee'}</div>
              <button className="modal-close" onClick={() => setModal(false)}><X /></button>
            </div>
            <div className="form-grid">
              <div className="form-group"><label>Name *</label><input value={form.name} onChange={e => setForm({...form, name: e.target.value})} /></div>
              <div className="form-group"><label>Email</label><input type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} /></div>
              <div className="form-group"><label>Phone</label><input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} /></div>
              <div className="form-group"><label>Department</label><input value={form.department} onChange={e => setForm({...form, department: e.target.value})} /></div>
              <div className="form-group"><label>Job Title</label><input value={form.job_title} onChange={e => setForm({...form, job_title: e.target.value})} /></div>
              <div className="form-group"><label>Salary</label><input type="number" value={form.salary} onChange={e => setForm({...form, salary: e.target.value})} /></div>
              <div className="form-group"><label>Hire Date</label><input type="date" value={form.hire_date} onChange={e => setForm({...form, hire_date: e.target.value})} /></div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
