import React, { useEffect, useState } from 'react';
import { Plus, X } from 'lucide-react';
import api from '../services/api';

const statusBadge = s => {
  const map = { paid: 'badge-green', sent: 'badge-blue', draft: 'badge-gray', overdue: 'badge-red', cancelled: 'badge-gray' };
  return <span className={`badge ${map[s] || 'badge-gray'}`}>{s}</span>;
};

export default function Invoices() {
  const [invoices, setInvoices]   = useState([]);
  const [customers, setCustomers] = useState([]);
  const [products, setProducts]   = useState([]);
  const [modal, setModal]         = useState(false);
  const [loading, setLoading]     = useState(true);
  const [form, setForm] = useState({ customer_id: '', due_date: '', notes: '', tax: 0, lines: [] });

  const load = () => Promise.all([
    api.get('/invoices/'),
    api.get('/customers/'),
    api.get('/products/')
  ]).then(([inv, cust, prod]) => {
    setInvoices(inv.data); setCustomers(cust.data); setProducts(prod.data); setLoading(false);
  });

  useEffect(() => { load(); }, []);

  function addLine() { setForm(f => ({ ...f, lines: [...f.lines, { description: '', quantity: 1, unit_price: 0, product_id: null }] })); }
  function updateLine(i, key, val) { setForm(f => { const l = [...f.lines]; l[i] = { ...l[i], [key]: val }; return { ...f, lines: l }; }); }
  function removeLine(i) { setForm(f => ({ ...f, lines: f.lines.filter((_, idx) => idx !== i) })); }

  const subtotal = form.lines.reduce((s, l) => s + (l.quantity * l.unit_price), 0);
  const total = subtotal + (+form.tax || 0);

  async function save() {
    await api.post('/invoices/', { ...form, customer_id: +form.customer_id, tax: +form.tax });
    setModal(false); load();
  }

  async function changeStatus(id, status) {
    await api.put(`/invoices/${id}/status?status=${status}`); load();
  }

  return (
    <div>
      <div className="page-header page-header-row">
        <div><h1>Invoices</h1><p>Track billing and payments</p></div>
        <button className="btn btn-primary" onClick={() => { setForm({ customer_id: '', due_date: '', notes: '', tax: 0, lines: [] }); setModal(true); }}><Plus /> New Invoice</button>
      </div>

      <div className="card">
        {loading ? <div className="loading">Loading...</div> : invoices.length === 0 ? (
          <div className="empty-state"><p>No invoices yet</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Invoice #</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {invoices.map(inv => (
                  <tr key={inv.id}>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>{inv.number}</td>
                    <td>{customers.find(c => c.id === inv.customer_id)?.name || inv.customer_id}</td>
                    <td style={{ color: 'var(--muted)' }}>{new Date(inv.issue_date).toLocaleDateString()}</td>
                    <td style={{ fontWeight: 600 }}>${inv.total?.toLocaleString()}</td>
                    <td>{statusBadge(inv.status)}</td>
                    <td>
                      <select
                        value={inv.status}
                        onChange={e => changeStatus(inv.id, e.target.value)}
                        style={{ padding: '4px 8px', fontSize: 12, width: 'auto' }}
                      >
                        {['draft','sent','paid','overdue','cancelled'].map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal" style={{ maxWidth: 680 }}>
            <div className="modal-header">
              <div className="modal-title">New Invoice</div>
              <button className="modal-close" onClick={() => setModal(false)}><X /></button>
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label>Customer *</label>
                <select value={form.customer_id} onChange={e => setForm({...form, customer_id: e.target.value})}>
                  <option value="">Select customer</option>
                  {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Due Date</label>
                <input type="date" value={form.due_date} onChange={e => setForm({...form, due_date: e.target.value})} />
              </div>
            </div>

            <div style={{ marginBottom: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <label style={{ marginBottom: 0 }}>Line Items</label>
                <button className="btn btn-ghost" style={{ padding: '4px 10px', fontSize: 12 }} onClick={addLine}><Plus style={{ width: 12 }} /> Add Line</button>
              </div>
              {form.lines.map((l, i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '2fr 80px 100px 30px', gap: 8, marginBottom: 8 }}>
                  <input placeholder="Description" value={l.description} onChange={e => updateLine(i, 'description', e.target.value)} />
                  <input type="number" placeholder="Qty" value={l.quantity} onChange={e => updateLine(i, 'quantity', +e.target.value)} />
                  <input type="number" placeholder="Unit price" value={l.unit_price} onChange={e => updateLine(i, 'unit_price', +e.target.value)} />
                  <button className="btn btn-danger" style={{ padding: '4px 6px' }} onClick={() => removeLine(i)}><X style={{ width: 12 }} /></button>
                </div>
              ))}
            </div>

            <div className="form-grid">
              <div className="form-group"><label>Tax Amount</label><input type="number" value={form.tax} onChange={e => setForm({...form, tax: +e.target.value})} /></div>
              <div className="form-group">
                <label>Totals</label>
                <div style={{ background: 'var(--bg3)', borderRadius: 8, padding: '9px 13px', fontSize: 13 }}>
                  Subtotal: <strong>${subtotal.toFixed(2)}</strong> | Total: <strong style={{ color: 'var(--accent)' }}>${total.toFixed(2)}</strong>
                </div>
              </div>
            </div>

            <div className="form-group"><label>Notes</label><textarea value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} /></div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>Create Invoice</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
