import React, { useEffect, useState } from 'react';
import { Plus, Search, Pencil, Trash2, X } from 'lucide-react';
import api from '../services/api';

const empty = { name: '', code: '', description: '', price: 0, cost: 0, stock: 0, unit: 'unit', category: '' };

export default function Products() {
  const [products, setProducts] = useState([]);
  const [search, setSearch]     = useState('');
  const [modal, setModal]       = useState(false);
  const [form, setForm]         = useState(empty);
  const [editId, setEditId]     = useState(null);
  const [loading, setLoading]   = useState(true);

  const load = () => api.get('/products/').then(r => { setProducts(r.data); setLoading(false); });
  useEffect(() => { load(); }, []);

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    (p.code || '').toLowerCase().includes(search.toLowerCase())
  );

  function openAdd() { setForm(empty); setEditId(null); setModal(true); }
  function openEdit(p) { setForm({ name: p.name, code: p.code||'', description: p.description||'', price: p.price, cost: p.cost, stock: p.stock, unit: p.unit, category: p.category||'' }); setEditId(p.id); setModal(true); }

  async function save() {
    if (editId) await api.put(`/products/${editId}`, form);
    else await api.post('/products/', form);
    setModal(false); load();
  }

  async function remove(id) {
    if (!window.confirm('Delete this product?')) return;
    await api.delete(`/products/${id}`); load();
  }

  const stockColor = s => s > 50 ? 'var(--green)' : s > 10 ? 'var(--amber)' : 'var(--red)';

  return (
    <div>
      <div className="page-header page-header-row">
        <div><h1>Products</h1><p>Manage your product catalog</p></div>
        <button className="btn btn-primary" onClick={openAdd}><Plus /> Add Product</button>
      </div>

      <div className="card">
        <div className="search-bar" style={{ marginBottom: 18 }}>
          <Search /><input placeholder="Search by name or code..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {loading ? <div className="loading">Loading...</div> : filtered.length === 0 ? (
          <div className="empty-state"><p>No products found</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Code</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th></th></tr></thead>
              <tbody>
                {filtered.map(p => (
                  <tr key={p.id}>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--muted)' }}>{p.code || '—'}</td>
                    <td style={{ fontWeight: 500 }}>{p.name}</td>
                    <td>{p.category || '—'}</td>
                    <td>${p.price.toLocaleString()}</td>
                    <td style={{ color: stockColor(p.stock), fontFamily: 'var(--mono)', fontSize: 13 }}>{p.stock} {p.unit}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-ghost" style={{ padding: '5px 9px' }} onClick={() => openEdit(p)}><Pencil style={{ width: 13 }} /></button>
                        <button className="btn btn-danger" style={{ padding: '5px 9px' }} onClick={() => remove(p.id)}><Trash2 style={{ width: 13 }} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">{editId ? 'Edit Product' : 'Add Product'}</div>
              <button className="modal-close" onClick={() => setModal(false)}><X /></button>
            </div>
            <div className="form-grid">
              <div className="form-group"><label>Name *</label><input value={form.name} onChange={e => setForm({...form, name: e.target.value})} /></div>
              <div className="form-group"><label>Code</label><input value={form.code} onChange={e => setForm({...form, code: e.target.value})} /></div>
              <div className="form-group"><label>Category</label><input value={form.category} onChange={e => setForm({...form, category: e.target.value})} /></div>
              <div className="form-group"><label>Unit</label><input value={form.unit} onChange={e => setForm({...form, unit: e.target.value})} /></div>
              <div className="form-group"><label>Sale Price</label><input type="number" value={form.price} onChange={e => setForm({...form, price: +e.target.value})} /></div>
              <div className="form-group"><label>Cost Price</label><input type="number" value={form.cost} onChange={e => setForm({...form, cost: +e.target.value})} /></div>
              <div className="form-group"><label>Stock Quantity</label><input type="number" value={form.stock} onChange={e => setForm({...form, stock: +e.target.value})} /></div>
            </div>
            <div className="form-group"><label>Description</label><textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} /></div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
