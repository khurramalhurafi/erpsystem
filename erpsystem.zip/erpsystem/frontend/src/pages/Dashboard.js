import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import api from '../services/api';

const statusBadge = s => {
  const map = { paid: 'badge-green', sent: 'badge-blue', draft: 'badge-gray', overdue: 'badge-red', cancelled: 'badge-gray' };
  return <span className={`badge ${map[s] || 'badge-gray'}`}>{s}</span>;
};

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => { api.get('/dashboard/stats').then(r => setStats(r.data)); }, []);

  if (!stats) return <div className="loading">Loading dashboard...</div>;

  const chartData = [
    { name: 'Paid',    value: stats.paid_revenue },
    { name: 'Pending', value: stats.pending_revenue },
  ];

  return (
    <div>
      <div className="page-header">
        <h1>Welcome back, {user.name?.split(' ')[0]} 👋</h1>
        <p>Here's what's happening in your business today.</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-label">Total Customers</div>
          <div className="stat-value blue">{stats.customers}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Products</div>
          <div className="stat-value blue">{stats.products}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Employees</div>
          <div className="stat-value blue">{stats.employees}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total Invoices</div>
          <div className="stat-value blue">{stats.invoices}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Revenue (Paid)</div>
          <div className="stat-value green">${stats.paid_revenue.toLocaleString()}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Pending Revenue</div>
          <div className="stat-value amber">${stats.pending_revenue.toLocaleString()}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Overdue Invoices</div>
          <div className="stat-value red">{stats.overdue_count}</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div className="card">
          <div className="card-title">Revenue Overview</div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={chartData} barSize={40}>
              <XAxis dataKey="name" tick={{ fill: '#7b82a0', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#7b82a0', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: '#1e2333', border: '1px solid #2a2f42', borderRadius: 8, color: '#e8eaf0' }}
                formatter={v => [`$${v.toLocaleString()}`, '']}
              />
              <Bar dataKey="value" fill="#4f7cff" radius={[6,6,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="card-title">Recent Invoices</div>
          {stats.recent_invoices.length === 0
            ? <div className="empty-state"><p>No invoices yet</p></div>
            : <div className="table-wrap">
                <table>
                  <thead><tr><th>Number</th><th>Amount</th><th>Status</th></tr></thead>
                  <tbody>
                    {stats.recent_invoices.map(inv => (
                      <tr key={inv.id}>
                        <td style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>{inv.number}</td>
                        <td>${inv.total?.toLocaleString()}</td>
                        <td>{statusBadge(inv.status)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
          }
        </div>
      </div>
    </div>
  );
}
