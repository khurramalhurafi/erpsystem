import React, { useEffect, useState } from 'react';
import { Upload, CheckCircle } from 'lucide-react';
import api from '../services/api';

export default function OdooImport() {
  const [status, setStatus]   = useState(null);
  const [result, setResult]   = useState(null);
  const [loading, setLoading] = useState(false);
  const [json, setJson]       = useState('');
  const [error, setError]     = useState('');

  useEffect(() => { api.get('/odoo/status').then(r => setStatus(r.data)); }, []);

  async function runImport() {
    setError(''); setLoading(true);
    try {
      const payload = JSON.parse(json);
      const { data } = await api.post('/odoo/import', payload);
      setResult(data.imported);
      api.get('/odoo/status').then(r => setStatus(r.data));
    } catch (e) {
      setError(e.response?.data?.detail || 'Invalid JSON or import failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Odoo 8 Data Import</h1>
        <p>Migrate your existing Odoo data into the new ERP system. Existing records are never overwritten.</p>
      </div>

      {status && (
        <div className="stats-grid" style={{ marginBottom: 24 }}>
          <div className="stat-card"><div className="stat-label">Customers Imported</div><div className="stat-value green">{status.customers_with_odoo_id}</div></div>
          <div className="stat-card"><div className="stat-label">Products Imported</div><div className="stat-value green">{status.products_with_odoo_id}</div></div>
          <div className="stat-card"><div className="stat-label">Employees Imported</div><div className="stat-value green">{status.employees_with_odoo_id}</div></div>
        </div>
      )}

      {result && (
        <div style={{ background: 'rgba(52,211,153,0.08)', border: '1px solid rgba(52,211,153,0.2)', borderRadius: 10, padding: 18, marginBottom: 20, display: 'flex', gap: 12, alignItems: 'center' }}>
          <CheckCircle style={{ color: 'var(--green)', flexShrink: 0 }} />
          <div>
            <div style={{ fontWeight: 600, color: 'var(--green)' }}>Import successful!</div>
            <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
              Customers: {result.customers} · Products: {result.products} · Employees: {result.employees} · Skipped (already exist): {result.skipped}
            </div>
          </div>
        </div>
      )}

      <div className="card">
        <div className="card-title">Paste Odoo Export (JSON)</div>
        <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 16 }}>
          Export your Odoo data as JSON and paste it below. The format should be:
        </p>
        <pre style={{ background: 'var(--bg3)', borderRadius: 8, padding: 16, fontSize: 12, fontFamily: 'var(--mono)', color: 'var(--muted)', marginBottom: 16, overflowX: 'auto' }}>{`{
  "customers": [
    { "id": 1, "name": "Acme Corp", "email": "info@acme.com", "phone": "+1234", "city": "Dubai" }
  ],
  "products": [
    { "id": 1, "name": "Widget A", "default_code": "WGT-001", "list_price": 50.0, "qty_available": 100 }
  ],
  "employees": [
    { "id": 1, "name": "Ahmed Ali", "work_email": "ahmed@company.com", "department_name": "Sales", "wage": 5000 }
  ]
}`}</pre>

        {error && <div className="login-error" style={{ marginBottom: 14 }}>{error}</div>}

        <div className="form-group">
          <label>JSON Data</label>
          <textarea
            value={json}
            onChange={e => setJson(e.target.value)}
            placeholder='{ "customers": [], "products": [], "employees": [] }'
            style={{ minHeight: 200, fontFamily: 'var(--mono)', fontSize: 12 }}
          />
        </div>

        <button className="btn btn-primary" onClick={runImport} disabled={loading || !json.trim()}>
          <Upload /> {loading ? 'Importing...' : 'Run Import'}
        </button>
      </div>
    </div>
  );
}
